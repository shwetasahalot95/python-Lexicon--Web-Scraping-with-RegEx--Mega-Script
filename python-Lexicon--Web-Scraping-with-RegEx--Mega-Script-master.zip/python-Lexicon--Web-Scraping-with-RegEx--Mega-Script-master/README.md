# python-Web-Scraping-with-RegEx--Mega-Script

A Python script that scrapes off word of the day from 5 different websites, along with a phrase of the day and a thought for today. The script writes these words to a text file 'today.txt', an html file 'today.html' and an archive file 'archive.txt'. Once the script finishes, it opens the folder containing these files, and opens these files in notepad and default browser. 

![Alt text](screenshot1.PNG?raw=true "3python-Web-Scraping-with-RegEx")
![Alt text](screenshot2.PNG?raw=true "3python-Web-Scraping-with-RegEx")
![Alt text](screenshot3.PNG?raw=true "3python-Web-Scraping-with-RegEx")
![Alt text](screenshot4.PNG?raw=true "3python-Web-Scraping-with-RegEx")
